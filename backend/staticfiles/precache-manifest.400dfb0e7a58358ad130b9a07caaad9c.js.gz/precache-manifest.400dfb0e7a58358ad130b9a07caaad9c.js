self.__precacheManifest = [
  {
    "revision": "ca4610225962d0661176",
    "url": "http://0.0.0.0:8080/css/app.e99da2b6.css"
  },
  {
    "revision": "ca4610225962d0661176",
    "url": "http://0.0.0.0:8080/app.js"
  },
  {
    "revision": "426439788ec5ba772cdf94057f6f4659",
    "url": "http://0.0.0.0:8080/fonts/nucleo-icons.42643978.woff2"
  },
  {
    "revision": "c1733565b32b585676302d4233c39da8",
    "url": "http://0.0.0.0:8080/fonts/nucleo-icons.c1733565.eot"
  },
  {
    "revision": "2569aaea6eaaf8cd210db7f2fa016743",
    "url": "http://0.0.0.0:8080/fonts/nucleo-icons.2569aaea.woff"
  },
  {
    "revision": "f82ec6ba2dc4181db2af35c499462840",
    "url": "http://0.0.0.0:8080/fonts/nucleo-icons.f82ec6ba.ttf"
  },
  {
    "revision": "0b8a30b10cbe7708d5f3a4b007c1d665",
    "url": "http://0.0.0.0:8080/img/nucleo-icons.0b8a30b1.svg"
  },
  {
    "revision": "af7ae505a9eed503f8b8e6982036873e",
    "url": "http://0.0.0.0:8080/fonts/fontawesome-webfont.af7ae505.woff2"
  },
  {
    "revision": "fee66e712a8a08eef5805a46892932ad",
    "url": "http://0.0.0.0:8080/fonts/fontawesome-webfont.fee66e71.woff"
  },
  {
    "revision": "674f50d287a8c48dc19ba404d20fe713",
    "url": "http://0.0.0.0:8080/fonts/fontawesome-webfont.674f50d2.eot"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "http://0.0.0.0:8080/fonts/fontawesome-webfont.b06871f2.ttf"
  },
  {
    "revision": "912ec66d7572ff821749319396470bde",
    "url": "http://0.0.0.0:8080/img/fontawesome-webfont.912ec66d.svg"
  },
  {
    "revision": "8ae358476e615a9d4bb2cfb2e0cd57c8",
    "url": "http://0.0.0.0:8080/index.html"
  }
];